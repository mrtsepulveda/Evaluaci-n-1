// ==========================================
// CONFIGURACIÓN GLOBAL Y UTILIDADES
// ==========================================

// Expresiones regulares compartidas (Declaradas una sola vez)
const formatoCorreo = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
const formatoRut = /^[0-9]+[0-9kK]$/; // Solo números y termina en número o K

// Función auxiliar para mostrar/ocultar errores (Evita repetir código)
function manejarError(idElemento, mensaje) {
    let elemento = document.getElementById(idElemento);
    if (elemento) {
        if (mensaje) {
            elemento.innerText = mensaje;
            elemento.style.display = "block";
        } else {
            elemento.style.display = "none";
        }
    }
}

// ==========================================
// SECCIÓN 1: PRODUCTOS DESTACADOS Y CATÁLOGO
// ==========================================
const productosDestacados = [
    { id: 'HE001', nombre: 'Taladro percutor 650W 13mm', descripcion: 'Potente y versátil para perforaciones en madera, metal y hormigón.', categoria: 'Herramientas', precio: 79990, imagen: 'img/Taladro percutor 650W 13mm.jpg', stock: true },
    { id: 'TR005', nombre: 'Taco fisher S8 bolsa 50 unid.', descripcion: 'Máxima fijación y seguridad para instalaciones en muros sólidos y huecos.', categoria: 'Tornillería', precio: 2890, imagen: 'img/Taco fisher S8 bolsa 50 unid..jpg', stock: true },
    { id: 'SE003', nombre: 'Antiparras de seguridad clear', descripcion: 'Diseño ergonómico con protección UV y tratamiento anti-empañantamiento.', categoria: 'Seguridad', precio: 2490, imagen: 'img/antiparras.jpg', stock: true },
    { id: 'MC004', nombre: 'Mortero nivelador piso 25 kg', descripcion: 'Ideal para alisar superficies antes de instalar pisos flotantes o cerámicos.', categoria: 'Mat. Construcción', precio: 6490, imagen: 'img/Mortero nivelador piso 20 kg.jpg', enOferta: true, precioOferta: 5192, stock: true },
    { id: 'MD004', nombre: 'MDF 15mm 1.22x2.44m', descripcion: 'Tablero de fibra de madera de alta densidad, corte limpio y uniforme.', categoria: 'Madera', precio: 27990, imagen: 'img/MDF 15mm 1.22x2.44m.jpg', stock: true },
    { id: 'HM007', nombre: 'Serrucho 20" 7 dientes por pulgada', descripcion: 'Hoja de acero templado con dientes triscados para cortes rápidos y precisos.', categoria: 'Herramientas', precio: 9490, imagen: 'img/serrucho.jpg', stock: true },
];

function cargarDestacados() {
    let contenedor = document.getElementById("destacados-container");
    
    if (contenedor !== null) {
        contenedor.innerHTML = ""; 
        for (let i = 0; i < productosDestacados.length; i++) {
            let producto = productosDestacados[i];
            
            // Condicional para destacar el precio si está en oferta
            let infoPrecio = `<p><strong>Precio: $${producto.precio}</strong></p>`;
            if (producto.enOferta === true) {
                infoPrecio = `<p><strike>Normal: $${producto.precio}</strike><br>
                              <strong style="color:red;">OFERTA: $${producto.precioOferta}</strong></p>`;
            }
            
            // Verificamos el stock para el botón
            let botonAccion = `<button onclick="agregarAlCarrito('${producto.id}')">Agregar al Carrito</button>`;
            if (producto.stock === false) {
                botonAccion = `<button disabled style="background-color: #cccccc; cursor: not-allowed;">No disponible</button>`;
            }

            let html = `
                <div class="producto-card">
                    <img src="${producto.imagen}" alt="${producto.nombre}" style="width: 100%; height: 150px; object-fit: cover; border-radius: 4px;">
                    <h3>${producto.nombre}</h3>
                    <p style="font-size: 13px; color: #666; min-height: 35px;">${producto.descripcion}</p>
                    ${infoPrecio}
                    ${botonAccion}
                </div>
            `;
            
            contenedor.innerHTML += html;
        }
    }
}

const productos = [
    { id: 'MC001', nombre: 'Cemento Polpaico gris 25 kg', categoria: 'Mat. Construcción', precio: 5990, imagen: 'https://placehold.co/150x150?text=Cemento+Polpaic', stock: true },
    { id: 'MC002', nombre: 'Cemento Melón blanco 25 kg', categoria: 'Mat. Construcción', precio: 7490, imagen: 'https://placehold.co/150x150?text=Cemento+Melón+b', stock: true },
    { id: 'MC003', nombre: 'Mortero cola cerámica 25 kg', categoria: 'Mat. Construcción', precio: 5200, imagen: 'https://placehold.co/150x150?text=Mortero+cola+ce', stock: true },
    { id: 'MC004', nombre: 'Mortero nivelador piso 25 kg', categoria: 'Mat. Construcción', precio: 6490, imagen: 'https://placehold.co/150x150?text=Mortero+nivelad', enOferta: true, precioOferta: 5192, stock: true },
    { id: 'MC005', nombre: 'Arena fina construcción 25 kg', categoria: 'Mat. Construcción', precio: 1800, imagen: 'https://placehold.co/150x150?text=Arena+fina+cons', enOferta: true, precioOferta: 1440, stock: true },
    { id: 'MC006', nombre: 'Ripio 25 kg', categoria: 'Mat. Construcción', precio: 1500, imagen: 'https://placehold.co/150x150?text=Ripio+25+kg', stock: true },
    { id: 'MC007', nombre: 'Ladrillo fiscal N°5', categoria: 'Mat. Construcción', precio: 380, imagen: 'https://placehold.co/150x150?text=Ladrillo+fiscal', stock: true },
    { id: 'MC008', nombre: 'Ladrillo prensado 6x14x29 cm', categoria: 'Mat. Construcción', precio: 550, imagen: 'https://placehold.co/150x150?text=Ladrillo+prensa', stock: true },
    { id: 'MC009', nombre: 'Bloque de hormigón 19x19x39 cm', categoria: 'Mat. Construcción', precio: 1200, imagen: 'https://placehold.co/150x150?text=Bloque+de+hormi', stock: true },
    { id: 'MC010', nombre: 'Bloque liviano 10x20x40 cm', categoria: 'Mat. Construcción', precio: 1690, imagen: 'https://placehold.co/150x150?text=Bloque+liviano+', stock: true },
    { id: 'PT001', nombre: 'Pintura látex interior 1 galón blanco', categoria: 'Pinturas', precio: 9990, imagen: 'https://placehold.co/150x150?text=Pintura+látex+i', stock: true },
    { id: 'PT002', nombre: 'Pintura látex interior 4 litros (varios col.)', categoria: 'Pinturas', precio: 12990, imagen: 'https://placehold.co/150x150?text=Pintura+látex+i', enOferta: true, precioOferta: 10392, stock: true },
    { id: 'PT003', nombre: 'Pintura látex exterior 1 galón blanco', categoria: 'Pinturas', precio: 13990, imagen: 'https://placehold.co/150x150?text=Pintura+látex+e', stock: true },
    { id: 'PT004', nombre: 'Esmalte sintético 1/4 litro (varios col.)', categoria: 'Pinturas', precio: 4290, imagen: 'https://placehold.co/150x150?text=Esmalte+sintéti', enOferta: true, precioOferta: 3432, stock: true },
    { id: 'PT005', nombre: 'Esmalte sintético 1 litro (varios col.)', categoria: 'Pinturas', precio: 9490, imagen: 'https://placehold.co/150x150?text=Esmalte+sintéti', enOferta: true, precioOferta: 7592, stock: true },
    { id: 'PT006', nombre: 'Pintura antihumedad 1 galón blanco', categoria: 'Pinturas', precio: 17990, imagen: 'https://placehold.co/150x150?text=Pintura+antihum', stock: true },
    { id: 'PT007', nombre: 'Rodillo lana 23 cm con mango', categoria: 'Pinturas', precio: 3990, imagen: 'https://placehold.co/150x150?text=Rodillo+lana+23', stock: true },
    { id: 'PT008', nombre: 'Brocha cerda natural 3"', categoria: 'Pinturas', precio: 1690, imagen: 'https://placehold.co/150x150?text=Brocha+cerda+na', enOferta: true, precioOferta: 1352, stock: true },
    { id: 'PT009', nombre: 'Cinta de enmascarar 24mm x 50m', categoria: 'Pinturas', precio: 2490, imagen: 'https://placehold.co/150x150?text=Cinta+de+enmasc', stock: true },
    { id: 'HM001', nombre: 'Martillo carpintero 500g', categoria: 'Herramientas', precio: 7990, imagen: 'https://placehold.co/150x150?text=Martillo+carpin', stock: true },
    { id: 'HM002', nombre: 'Alicate universal 8"', categoria: 'Herramientas', precio: 7290, imagen: 'https://placehold.co/150x150?text=Alicate+univers', stock: true },
    { id: 'HM003', nombre: 'Destornillador plano 6x100mm', categoria: 'Herramientas', precio: 1990, imagen: 'https://placehold.co/150x150?text=Destornillador+', stock: true },
    { id: 'HM004', nombre: 'Destornillador Phillips PH2 6x100mm', categoria: 'Herramientas', precio: 1990, imagen: 'https://placehold.co/150x150?text=Destornillador+', stock: true },
    { id: 'HM005', nombre: 'Llave ajustable 10"', categoria: 'Herramientas', precio: 8490, imagen: 'https://placehold.co/150x150?text=Llave+ajustable', stock: true },
    { id: 'HM006', nombre: 'Juego llaves hexagonales métrico x9', categoria: 'Herramientas', precio: 5490, imagen: 'https://placehold.co/150x150?text=Juego+llaves+he', stock: true },
    { id: 'HM007', nombre: 'Serrucho 20" 7 dientes por pulgada', categoria: 'Herramientas', precio: 9490, imagen: 'https://placehold.co/150x150?text=Serrucho+20"+7+', stock: true },
    { id: 'HM008', nombre: 'Nivel de burbuja 60 cm', categoria: 'Herramientas', precio: 10490, imagen: 'https://placehold.co/150x150?text=Nivel+de+burbuj', stock: true },
    { id: 'HM009', nombre: 'Metro de tela 5m', categoria: 'Herramientas', precio: 4290, imagen: 'https://placehold.co/150x150?text=Metro+de+tela+5', enOferta: true, precioOferta: 3432, stock: true },
    { id: 'HM010', nombre: 'Cinta métrica 8m autoblocante', categoria: 'Herramientas', precio: 6490, imagen: 'https://placehold.co/150x150?text=Cinta+métrica+8', enOferta: true, precioOferta: 5192, stock: true },
    { id: 'HE001', nombre: 'Taladro percutor 650W 13mm', categoria: 'Herramientas', precio: 79990, imagen: 'https://placehold.co/150x150?text=Taladro+percuto', stock: true },
    { id: 'HE002', nombre: 'Atornillador inalámbrico 12V (kit)', categoria: 'Herramientas', precio: 104990, imagen: 'https://placehold.co/150x150?text=Atornillador+in', stock: true },
    { id: 'HE003', nombre: 'Amoladora angular 4.5" 800W', categoria: 'Herramientas', precio: 54990, imagen: 'https://placehold.co/150x150?text=Amoladora+angul', enOferta: true, precioOferta: 43992, stock: true },
    { id: 'HE004', nombre: 'Sierra circular 7-1/4" 1200W', categoria: 'Herramientas', precio: 72990, imagen: 'https://placehold.co/150x150?text=Sierra+circular', stock: true },
    { id: 'HE005', nombre: 'Lijadora orbital 180W', categoria: 'Herramientas', precio: 34990, imagen: 'https://placehold.co/150x150?text=Lijadora+orbita', stock: true },
    { id: 'HE006', nombre: 'Caladora 500W', categoria: 'Herramientas', precio: 42990, imagen: 'https://placehold.co/150x150?text=Caladora+500W', stock: true },
    { id: 'GS001', nombre: 'Cañería PVC 1/2" x 6m', categoria: 'Gasfitería', precio: 5490, imagen: 'https://placehold.co/150x150?text=Cañería+PVC+1/2', enOferta: true, precioOferta: 4392, stock: true },
    { id: 'GS002', nombre: 'Cañería PVC 3/4" x 6m', categoria: 'Gasfitería', precio: 7490, imagen: 'https://placehold.co/150x150?text=Cañería+PVC+3/4', stock: true },
    { id: 'GS003', nombre: 'Cañería cobre 1/2" x 5m', categoria: 'Gasfitería', precio: 17990, imagen: 'https://placehold.co/150x150?text=Cañería+cobre+1', stock: true },
    { id: 'GS004', nombre: 'Codo PVC 1/2" 90°', categoria: 'Gasfitería', precio: 390, imagen: 'https://placehold.co/150x150?text=Codo+PVC+1/2"+9', stock: true },
    { id: 'GS005', nombre: 'Te PVC 1/2"', categoria: 'Gasfitería', precio: 450, imagen: 'https://placehold.co/150x150?text=Te+PVC+1/2"', stock: true },
    { id: 'GS006', nombre: 'Unión doble PVC 1/2"', categoria: 'Gasfitería', precio: 320, imagen: 'https://placehold.co/150x150?text=Unión+doble+PVC', stock: true },
    { id: 'GS007', nombre: 'Llave de paso esfera 1/2" latón', categoria: 'Gasfitería', precio: 3490, imagen: 'https://placehold.co/150x150?text=Llave+de+paso+e', stock: true },
    { id: 'GS008', nombre: 'Llave de paso esfera 3/4" latón', categoria: 'Gasfitería', precio: 4990, imagen: 'https://placehold.co/150x150?text=Llave+de+paso+e', stock: true },
    { id: 'GS009', nombre: 'Grifería lavamanos monocomando cromo', categoria: 'Gasfitería', precio: 22990, imagen: 'https://placehold.co/150x150?text=Grifería+lavama', stock: true },
    { id: 'GS010', nombre: 'Grifería cocina monocomando cuello alto', categoria: 'Gasfitería', precio: 28990, imagen: 'https://placehold.co/150x150?text=Grifería+cocina', stock: true },
    { id: 'GS011', nombre: 'Teflón 3/4" x 12m', categoria: 'Gasfitería', precio: 790, imagen: 'https://placehold.co/150x150?text=Teflón+3/4"+x+1', stock: true },
    { id: 'GS012', nombre: 'Silicona transparente 280ml', categoria: 'Gasfitería', precio: 5490, imagen: 'https://placehold.co/150x150?text=Silicona+transp', stock: true },
    { id: 'EL001', nombre: 'Cable unipolar 1.5mm² (por metro)', categoria: 'Electricidad', precio: 590, imagen: 'https://placehold.co/150x150?text=Cable+unipolar+', stock: true },
    { id: 'EL002', nombre: 'Cable unipolar 2.5mm² (por metro)', categoria: 'Electricidad', precio: 790, imagen: 'https://placehold.co/150x150?text=Cable+unipolar+', stock: true },
    { id: 'EL003', nombre: 'Cable dúplex paralelo 2x1.5mm² (por metro)', categoria: 'Electricidad', precio: 990, imagen: 'https://placehold.co/150x150?text=Cable+dúplex+pa', stock: true },
    { id: 'EL004', nombre: 'Enchufe empotrar 16A c/tierra (schuko)', categoria: 'Electricidad', precio: 3690, imagen: 'https://placehold.co/150x150?text=Enchufe+empotra', stock: true },
    { id: 'EL005', nombre: 'Enchufe doble empotrar 16A c/tierra', categoria: 'Electricidad', precio: 5490, imagen: 'https://placehold.co/150x150?text=Enchufe+doble+e', stock: true },
    { id: 'EL006', nombre: 'Interruptor simple empotrar', categoria: 'Electricidad', precio: 3190, imagen: 'https://placehold.co/150x150?text=Interruptor+sim', stock: true },
    { id: 'EL007', nombre: 'Interruptor doble empotrar', categoria: 'Electricidad', precio: 4290, imagen: 'https://placehold.co/150x150?text=Interruptor+dob', stock: true },
    { id: 'EL008', nombre: 'Tablero eléctrico 4 espacios DIN', categoria: 'Electricidad', precio: 22990, imagen: 'https://placehold.co/150x150?text=Tablero+eléctri', enOferta: true, precioOferta: 18392, stock: true },
    { id: 'EL009', nombre: 'Disyuntor termomagnético 16A unipolar', categoria: 'Electricidad', precio: 6490, imagen: 'https://placehold.co/150x150?text=Disyuntor+termo', stock: true },
    { id: 'EL010', nombre: 'Disyuntor termomagnético 25A unipolar', categoria: 'Electricidad', precio: 6990, imagen: 'https://placehold.co/150x150?text=Disyuntor+termo', stock: true },
    { id: 'EL011', nombre: 'Ampolleta LED 9W E27 luz fría', categoria: 'Electricidad', precio: 3990, imagen: 'https://placehold.co/150x150?text=Ampolleta+LED+9', stock: true },
    { id: 'EL012', nombre: 'Ampolleta LED 12W E27 luz cálida', categoria: 'Electricidad', precio: 4490, imagen: 'https://placehold.co/150x150?text=Ampolleta+LED+1', stock: true },
    { id: 'EL013', nombre: 'Panel LED empotrar 18W 22cm', categoria: 'Electricidad', precio: 11490, imagen: 'https://placehold.co/150x150?text=Panel+LED+empot', stock: true },
    { id: 'TR001', nombre: 'Tornillo autoperf. 8x1" caja 100 unid.', categoria: 'Tornillería', precio: 2990, imagen: 'https://placehold.co/150x150?text=Tornillo+autope', stock: true },
    { id: 'TR002', nombre: 'Tornillo madera 4x40mm caja 100 unid.', categoria: 'Tornillería', precio: 2490, imagen: 'https://placehold.co/150x150?text=Tornillo+madera', stock: true },
    { id: 'TR003', nombre: 'Tornillo volcanita 3.5x25mm caja 200 unid.', categoria: 'Tornillería', precio: 3490, imagen: 'https://placehold.co/150x150?text=Tornillo+volcan', stock: true },
    { id: 'TR004', nombre: 'Taco fisher S6 bolsa 100 unid.', categoria: 'Tornillería', precio: 3190, imagen: 'https://placehold.co/150x150?text=Taco+fisher+S6+', stock: true },
    { id: 'TR005', nombre: 'Taco fisher S8 bolsa 50 unid.', categoria: 'Tornillería', precio: 2890, imagen: 'https://placehold.co/150x150?text=Taco+fisher+S8+', stock: true },
    { id: 'TR006', nombre: 'Perno hex. 3/8" x 2" c/tuerca y golilla', categoria: 'Tornillería', precio: 290, imagen: 'https://placehold.co/150x150?text=Perno+hex.+3/8"', stock: true },
    { id: 'TR007', nombre: 'Perno de anclaje 10x100mm', categoria: 'Tornillería', precio: 990, imagen: 'https://placehold.co/150x150?text=Perno+de+anclaj', stock: true },
    { id: 'TR008', nombre: 'Anclaje químico epoxi 300ml', categoria: 'Tornillería', precio: 15990, imagen: 'https://placehold.co/150x150?text=Anclaje+químico', stock: true },
    { id: 'MD001', nombre: 'Pino cepillado 1x3" x 3m', categoria: 'Madera', precio: 4290, imagen: 'https://placehold.co/150x150?text=Pino+cepillado+', stock: true },
    { id: 'MD002', nombre: 'Pino cepillado 2x4" x 3m', categoria: 'Madera', precio: 7490, imagen: 'https://placehold.co/150x150?text=Pino+cepillado+', enOferta: true, precioOferta: 5992, stock: true },
    { id: 'MD003', nombre: 'Terciado estructural 18mm 1.22x2.44m', categoria: 'Madera', precio: 34990, imagen: 'https://placehold.co/150x150?text=Terciado+estruc', stock: true },
    { id: 'MD004', nombre: 'MDF 15mm 1.22x2.44m', categoria: 'Madera', precio: 27990, imagen: 'https://placehold.co/150x150?text=MDF+15mm+1.22x2', stock: true },
    { id: 'MD005', nombre: 'OSB 9mm 1.22x2.44m', categoria: 'Madera', precio: 18990, imagen: 'https://placehold.co/150x150?text=OSB+9mm+1.22x2.', stock: true },
    { id: 'MD006', nombre: 'Volcanita estándar 10mm 1.2x2.4m', categoria: 'Madera', precio: 8990, imagen: 'https://placehold.co/150x150?text=Volcanita+están', stock: true },
    { id: 'MD007', nombre: 'Volcanita resistente humedad 10mm', categoria: 'Madera', precio: 11990, imagen: 'https://placehold.co/150x150?text=Volcanita+resis', stock: true },
    { id: 'SE001', nombre: 'Casco seguridad blanco', categoria: 'Seguridad', precio: 6990, imagen: 'https://placehold.co/150x150?text=Casco+seguridad', enOferta: true, precioOferta: 5592, stock: true },
    { id: 'SE002', nombre: 'Guantes de cuero talla L', categoria: 'Seguridad', precio: 3690, imagen: 'https://placehold.co/150x150?text=Guantes+de+cuer', stock: true },
    { id: 'SE003', nombre: 'Antiparras de seguridad clear', categoria: 'Seguridad', precio: 2490, imagen: 'https://placehold.co/150x150?text=Antiparras+de+s', stock: true },
    { id: 'SE004', nombre: 'Mascarilla respirador N95 (caja x10)', categoria: 'Seguridad', precio: 10990, imagen: 'https://placehold.co/150x150?text=Mascarilla+resp', stock: true },
    { id: 'SE005', nombre: 'Arnés de seguridad 1 punto', categoria: 'Seguridad', precio: 34990, imagen: 'https://placehold.co/150x150?text=Arnés+de+seguri', stock: true },
    { id: 'JA001', nombre: 'Manguera riego 3/4" x 25m', categoria: 'Jardín', precio: 22990, imagen: 'https://placehold.co/150x150?text=Manguera+riego+', stock: true },
    { id: 'JA002', nombre: 'Manguera expandible 30m', categoria: 'Jardín', precio: 28990, imagen: 'https://placehold.co/150x150?text=Manguera+expand', enOferta: true, precioOferta: 23192, stock: true },
    { id: 'JA003', nombre: 'Pistola de riego 8 modos', categoria: 'Jardín', precio: 5490, imagen: 'https://placehold.co/150x150?text=Pistola+de+rieg', enOferta: true, precioOferta: 4392, stock: true },
    { id: 'JA004', nombre: 'Pala punta redonda #2 con mango', categoria: 'Jardín', precio: 10990, imagen: 'https://placehold.co/150x150?text=Pala+punta+redo', stock: true },
    { id: 'JA005', nombre: 'Rastrillo 16 dientes con mango', categoria: 'Jardín', precio: 9490, imagen: 'https://placehold.co/150x150?text=Rastrillo+16+di', stock: true }
];


function cargarCatalogo() {
    const contenedorCatalogo = document.getElementById("lista-catalogo");
    
    if (contenedorCatalogo !== null) {
        contenedorCatalogo.innerHTML = ""; 
        for (let i = 0; i < productos.length; i++) {
            let producto = productos[i];
            
            let infoPrecio = `<p><strong>$${producto.precio}</strong></p>`;
            if (producto.enOferta === true) {
                infoPrecio = `<p><strike>$${producto.precio}</strike> 
                              <strong style="color:red;">$${producto.precioOferta}</strong></p>`;
            }
            
            let botonAccion = `<button onclick="agregarAlCarrito('${producto.id}')">Agregar</button>`;
            let etiquetaStock = "";

            if (producto.stock === false) {
                etiquetaStock = `<p style="color: red; font-weight: bold;">¡Sin Stock!</p>`;
                botonAccion = `<button disabled style="background-color: #cccccc; cursor: not-allowed;">No disponible</button>`;
            }
            
            let htmlProducto = `
                <div class="producto-card">
                    <img src="${producto.imagen}" alt="${producto.nombre}" style="width: 100%; border-radius: 4px;">
                    <h3>${producto.nombre}</h3>
                    <p>Categoría: ${producto.categoria}</p>
                    ${infoPrecio}
                    ${etiquetaStock}
                    ${botonAccion}
                </div>
            `;
            
            contenedorCatalogo.innerHTML += htmlProducto;
        }
    }
}

// ==========================================
// SECCIÓN 2: FORMULARIO DE CONTACTO
// ==========================================
function validarContacto(evento) {
    evento.preventDefault(); 
    let esValido = true;

    let nombre = document.getElementById("nombre").value.trim();
    let correo = document.getElementById("correo").value.trim();
    let comentario = document.getElementById("comentario").value.trim();

    // 1. Nombre
    if (nombre === "" || nombre.length > 100) {
        manejarError("error-nombre", "Obligatorio y máximo 100 caracteres.");
        esValido = false;
    } else { manejarError("error-nombre", null); }

    // 2. Correo
    if (correo === "" || correo.length > 100 || !formatoCorreo.test(correo)) {
        manejarError("error-correo", "Obligatorio, máx 100 caracteres y formato válido.");
        esValido = false;
    } else { manejarError("error-correo", null); }

    // 3. Comentario
    if (comentario === "" || comentario.length > 500) {
        manejarError("error-comentario", "Obligatorio y máximo 500 caracteres.");
        esValido = false;
    } else { manejarError("error-comentario", null); }

    if (esValido) {
        alert("¡Mensaje enviado con éxito! Nos contactaremos a la brevedad.");
        document.getElementById("form-contacto").reset();
    }
    return esValido;
}

// ==========================================
// SECCIÓN 3: REGISTRO Y UBICACIÓN
// ==========================================
const datosRegiones = [
    { nombre: "Coquimbo", comunas: ["La Serena", "Coquimbo", "Vicuña", "Ovalle"] },
    { nombre: "Valparaíso", comunas: ["Valparaíso", "Viña del Mar", "Quilpué"] },
    { nombre: "Metropolitana", comunas: ["Santiago", "Quilicura", "Maipú", "Puente Alto"] }
];

function cargarRegiones() {
    let selectRegion = document.getElementById("region");
    if (!selectRegion) return;

    datosRegiones.forEach(region => {
        let opcion = document.createElement("option");
        opcion.value = region.nombre;
        opcion.text = region.nombre;
        selectRegion.appendChild(opcion);
    });
}

function actualizarComunas() {
    let selectRegion = document.getElementById("region");
    let selectComuna = document.getElementById("comuna");
    let regionSeleccionada = selectRegion.value;

    selectComuna.innerHTML = '<option value="">Seleccione Comuna...</option>';

    if (regionSeleccionada !== "") {
        let regionEncontrada = datosRegiones.find(r => r.nombre === regionSeleccionada);
        if (regionEncontrada) {
            regionEncontrada.comunas.forEach(comuna => {
                let opcion = document.createElement("option");
                opcion.value = comuna;
                opcion.text = comuna;
                selectComuna.appendChild(opcion);
            });
        }
    }
}

function validarRegistro(evento) {
    evento.preventDefault();
    let esValido = true;

    let rut = document.getElementById("rut").value.trim();
    let nombre = document.getElementById("nombre").value.trim();
    let apellidos = document.getElementById("apellidos").value.trim();
    let correo = document.getElementById("correo").value.trim();
    let tipoUsuario = document.getElementById("tipoUsuario").value;
    let region = document.getElementById("region").value;
    let comuna = document.getElementById("comuna").value;
    let direccion = document.getElementById("direccion").value.trim();

    // 1. RUT
    if (rut === "" || !formatoRut.test(rut)) {
        manejarError("error-rut", "Ingrese un RUN válido sin puntos ni guion (Ej: 123456789).");
        esValido = false;
    } else {
        let cuerpo = rut.substring(0, rut.length - 1);
        let dv = rut.substring(rut.length - 1).toUpperCase();
        let suma = 0;
        let multiplo = 2;

        for (let i = 1; i <= cuerpo.length; i++) {
            suma += multiplo * rut.charAt(cuerpo.length - i);
            multiplo = multiplo < 7 ? multiplo + 1 : 2;
        }
        
        let dvEsperado = 11 - (suma % 11);
        let dvCalculado = dvEsperado === 11 ? "0" : (dvEsperado === 10 ? "K" : dvEsperado.toString());

        if (dv !== dvCalculado) {
            manejarError("error-rut", "El RUN ingresado no es válido.");
            esValido = false;
        } else { manejarError("error-rut", null); }
    }

    // 2. Textos Simples
    if (nombre === "" || nombre.length > 50) { manejarError("error-nombre", "Obligatorio, máx 50."); esValido = false; } else { manejarError("error-nombre", null); }
    if (apellidos === "" || apellidos.length > 100) { manejarError("error-apellidos", "Obligatorio, máx 100."); esValido = false; } else { manejarError("error-apellidos", null); }
    if (correo === "" || correo.length > 100 || !formatoCorreo.test(correo)) { manejarError("error-correo", "Correo inválido."); esValido = false; } else { manejarError("error-correo", null); }
    
    // 3. Selectores
    if (tipoUsuario === "") { manejarError("error-tipo", "Seleccione tipo."); esValido = false; } else { manejarError("error-tipo", null); }
    if (region === "" || comuna === "") { manejarError("error-ubicacion", "Seleccione región y comuna."); esValido = false; } else { manejarError("error-ubicacion", null); }
    if (direccion === "" || direccion.length > 300) { manejarError("error-direccion", "Obligatoria, máx 300."); esValido = false; } else { manejarError("error-direccion", null); }

    if (esValido) {
        alert("Usuario registrado correctamente.");
        document.getElementById("form-registro").reset();
    }
    return esValido;
}

// ==========================================
// SECCIÓN 4: INICIO DE SESIÓN
// ==========================================
function validarLogin(evento) {
    evento.preventDefault();
    let esValido = true;

    let correo = document.getElementById("correoLogin").value.trim();
    let contrasena = document.getElementById("contrasena").value.trim();

    if (correo === "" || correo.length > 100 || !formatoCorreo.test(correo)) {
        manejarError("error-correo-login", "Correo inválido o vacío.");
        esValido = false;
    } else { manejarError("error-correo-login", null); }

    if (contrasena === "" || contrasena.length < 4 || contrasena.length > 10) {
        manejarError("error-contrasena", "Debe tener entre 4 y 10 caracteres.");
        esValido = false;
    } else { manejarError("error-contrasena", null); }

    if (esValido) {
        // Guardamos el usuario activo en el LocalStorage
        let sesionActiva = { correo: correo, rol: correo.includes("admin") ? "Administrador" : "Cliente" };
        localStorage.setItem("sesionFerreteria", JSON.stringify(sesionActiva));

        alert("Inicio de sesión exitoso. Bienvenido.");
        window.location.href = "index.html"; 
    }
    return esValido;
}

// Función para cerrar sesión
function cerrarSesion() {
    localStorage.removeItem("sesionFerreteria");
    alert("Has cerrado sesión.");
    window.location.href = "index.html";
}

// Función automática para actualizar la barra de navegación en todas las páginas
function verificarSesionBarra() {
    let sesion = localStorage.getItem("sesionFerreteria");
    
    // Buscamos los enlaces de login en el menú
    let navListas = document.querySelectorAll(".nav-principal ul");
    
    if (sesion && navListas.length > 0) {
        let datosSesion = JSON.parse(sesion);
        
        navListas.forEach(ul => {
            // Buscamos si existe el enlace de login para reemplazarlo
            let links = ul.getElementsByTagName("a");
            for (let i = 0; i < links.length; i++) {
                if (links[i].getAttribute("href") === "login.html") {
                    // Reemplazamos "Iniciar Sesión" por "Mi Perfil" y agregamos botón salir
                    let liPadre = links[i].parentElement;
                    liPadre.innerHTML = `<a href="perfil.html">Mi Perfil (${datosSesion.rol})</a>`;
                }
            }
            // Si es administrador, podemos inyectar un acceso directo al panel admin en el menú
            if (datosSesion.rol === "Administrador") {
                let existeAdmin = Array.from(links).some(l => l.getAttribute("href") === "admin.html");
                if (!existeAdmin) {
                    let nuevoLi = document.createElement("li");
                    nuevoLi.innerHTML = `<a href="admin.html" style="color: #ff9900;">Admin</a>`;
                    ul.appendChild(nuevoLi);
                }
            }
        });
    }
}

// Ejecutar la revisión de la barra al cargar cualquier página
verificarSesionBarra();

// ==========================================
// SECCIÓN 5: ÁREA ADMINISTRATIVA
// ==========================================
const listaUsuariosAdmin = [
    { nombre: "Dueño Ferretería", correo: "admin@losmaestros.cl", rol: "Administrador" },
    { nombre: "Valentina", correo: "valentina@test.cl", rol: "Cliente" }
];

function cargarTablaProductosAdmin() {
    let tbody = document.getElementById("tabla-productos-admin");
    if (!tbody) return;

    let filas = "";
    productos.forEach(producto => {
        let estadoStock = (producto.stock !== false) ? "Disponible" : "Sin Stock";
        let colorStock = (producto.stock !== false) ? "green" : "red";

        filas += `
            <tr>
                <td>${producto.id}</td>
                <td>${producto.nombre}</td>
                <td>$${producto.precio}</td>
                <td style="color: ${colorStock}; font-weight: bold;">${estadoStock}</td>
                <td>
                    <button onclick="cambiarStockAdmin('${producto.id}')" style="padding: 5px; background-color: #f0ad4e;">Cambiar Stock</button>
                </td>
            </tr>
        `;
    });
    tbody.innerHTML = filas;
}

function cambiarStockAdmin(idProducto) {
    let producto = productos.find(p => p.id === idProducto);
    if (producto) {
        producto.stock = (producto.stock === false) ? true : false;
        localStorage.setItem("catalogoFerreteria", JSON.stringify(productos));
        alert(`El stock de "${producto.nombre}" ha sido actualizado.`);
        cargarTablaProductosAdmin();
    }
}

function cargarTablaUsuariosAdmin() {
    let tbody = document.getElementById("tabla-usuarios-admin");
    if (!tbody) return;

    let filas = "";
    listaUsuariosAdmin.forEach(usuario => {
        filas += `
            <tr>
                <td>${usuario.nombre}</td>
                <td>${usuario.correo}</td>
                <td>${usuario.rol}</td>
                <td><button style="padding: 5px;">Editar</button></td>
            </tr>
        `;
    });
    tbody.innerHTML = filas;
}

// --- GESTIÓN DE PRODUCTOS DESDE EL ADMIN ---
function guardarProductoAdmin(evento) {
    evento.preventDefault();

    let id = document.getElementById("idProductoAdmin").value.trim();
    let categoria = document.getElementById("catProductoAdmin").value.trim();
    let nombre = document.getElementById("nombreProductoAdmin").value.trim();
    let precio = parseInt(document.getElementById("precioProductoAdmin").value);

    // Creamos el nuevo objeto de producto
    let nuevoProducto = {
        id: id,
        nombre: nombre,
        categoria: categoria,
        precio: precio,
        imagen: "img/logo_maestros.jpg", // Imagen por defecto local
        stock: true
    };

    // Verificamos si ya existe el producto en el arreglo global para actualizarlo, o agregarlo
    let index = productos.findIndex(p => p.id === id);
    if (index !== -1) {
        productos[index] = nuevoProducto; // Actualiza
        alert("Producto actualizado exitosamente.");
    } else {
        productos.push(nuevoProducto); // Agrega nuevo
        alert("Producto agregado al catálogo exitosamente.");
    }

    // Guardamos los cambios actualizados en localStorage para persistencia
    localStorage.setItem("catalogoFerreteria", JSON.stringify(productos));

    // Recargamos la tabla de administración
    cargarTablaProductosAdmin();
    document.getElementById("form-admin-producto").reset();
}

// Modifica al inicio de la carga del catálogo (en app.js) para que cargue los productos del LocalStorage si existen:
function inicializarCatalogo() {
    let catalogoGuardado = localStorage.getItem("catalogoFerreteria");
    if (catalogoGuardado !== null) {
        // Si el admin guardó cambios, reemplazamos el arreglo global con los datos del storage
        let parsed = JSON.parse(catalogoGuardado);
        productos.length = 0;
        parsed.forEach(p => productos.push(p));
    }
}
// Llama a inicializarCatalogo() antes de cargar el catálogo o destacados.
inicializarCatalogo();
// ==========================================
// SECCIÓN 6: SELECCIÓN Y LOCALSTORAGE (CARRITO)
// ==========================================
let carrito = [];

function cargarCarritoDesdeStorage() {
    let carritoGuardado = localStorage.getItem("carritoFerreteria");
    if (carritoGuardado !== null) {
        carrito = JSON.parse(carritoGuardado);
    }
    actualizarVistaCarrito();
}

function agregarAlCarrito(idProducto) {
    // Buscamos tanto en el catálogo general como en los productos destacados del inicio
    let productoSeleccionado = productos.find(p => p.id === idProducto) || productosDestacados.find(p => p.id === idProducto);
    
    if (productoSeleccionado) {
        if (productoSeleccionado.stock === false) {
            alert("Este producto se encuentra sin stock y no se puede agregar.");
            return;
        }
        carrito.push(productoSeleccionado);
        localStorage.setItem("carritoFerreteria", JSON.stringify(carrito));
        actualizarVistaCarrito();
        alert(`Se agregó "${productoSeleccionado.nombre}" a tu selección.`);
    }
}

function actualizarVistaCarrito() {
    const listaCarrito = document.getElementById("lista-carrito");
    const totalCarrito = document.getElementById("total-carrito");
    const contenedorBotonPagar = document.getElementById("contenedor-boton-pagar");

    if (listaCarrito && totalCarrito) {
        listaCarrito.innerHTML = ""; 
        let total = 0;

        carrito.forEach((item, index) => {
            let precioFinal = item.enOferta ? item.precioOferta : item.precio;
            total += precioFinal;

            let li = document.createElement("li");
            li.innerHTML = `${item.nombre} - $${precioFinal} 
                            <button onclick="quitarDelCarrito(${index})" style="padding: 2px 5px; margin-left: 10px; background: red; color: white; border: none; border-radius: 3px; cursor: pointer;">Quitar</button>`;
            listaCarrito.appendChild(li);
        });

        totalCarrito.innerText = total;

        // Mostrar u ocultar el botón de pagar según si hay productos
        if (contenedorBotonPagar) {
            if (carrito.length > 0) {
                contenedorBotonPagar.style.display = "flex";
            } else {
                contenedorBotonPagar.style.display = "none";
            }
        }
    }
}

function procesarPago() {
    if (carrito.length === 0) {
        alert("No hay productos en el carrito para pagar.");
        return;
    }

    let confirmar = confirm("¿Deseas confirmar y procesar el pago de tu compra en Ferretería Los Maestros?");
    
    if (confirmar) {
        alert("¡Compra realizada con éxito! Muchas gracias por preferirnos. Tu pedido está siendo preparado.");
        limpiarCarrito();
    }
}

function quitarDelCarrito(indice) {
    carrito.splice(indice, 1);
    localStorage.setItem("carritoFerreteria", JSON.stringify(carrito));
    actualizarVistaCarrito();
}

function limpiarCarrito() {
    carrito = [];
    localStorage.removeItem("carritoFerreteria");
    actualizarVistaCarrito();
}

// ==========================================
// INICIALIZACIÓN GLOBAL
// ==========================================
cargarDestacados();
cargarCatalogo(); 
cargarTablaProductosAdmin();
cargarTablaUsuariosAdmin();
cargarRegiones();
cargarCarritoDesdeStorage();