# Ferretería Los Maestros – Evaluación Parcial 2 (DSY1104)

Migración del sitio HTML de la Evaluación 1 a **React + Vite + TypeScript** con **Bootstrap**, **React Router** y pruebas con **Vitest + React Testing Library**.

## Cómo ejecutar

```bash
npm install
npm run dev          # servidor de desarrollo (http://localhost:5173)
npm run build        # compila TypeScript y genera /dist
npm run test:run     # ejecuta todas las pruebas una vez
npm run coverage     # pruebas + reporte de cobertura (carpeta /coverage y /reports)
```

Usuarios de prueba (cualquier contraseña de 4 a 10 caracteres):
- `admin@losmaestros.cl` → rol **Administrador** (accede a `/admin`)
- `valentina@test.cl` → rol **Cliente**

## Estructura (Atomic Design)

```
src/
├─ types/                interfaces de TypeScript (Producto, Usuario, Sesion, ...)
├─ data/                 fuente de datos simulada (CRUD) + sesión + carrito
├─ utils/validaciones.ts validaciones con mensajes específicos
├─ components/
│  ├─ atoms/             Boton, Entrada, AreaTexto, Seleccion, MensajeError, Etiqueta, Precio, ImagenProducto
│  ├─ molecules/         CampoTexto, CampoSeleccion, CampoAreaTexto, TarjetaProducto, BuscadorProductos,
│  │                     FilaCarrito, ItemNavegacion, TarjetaNovedad, Aviso
│  └─ organisms/         BarraNavegacion, PiePagina, BannerPrincipal, GrillaProductos, PanelCarrito,
│                        Formulario{Contacto,Login,Registro,Producto,Usuario}, Tabla{Productos,Usuarios}
├─ templates/            PlantillaPrincipal, PlantillaAdmin, RutaAdmin (protección de rutas)
└─ pages/                Inicio, Catalogo, DetalleProducto, Novedades, NovedadDetalle, Contacto, Login,
                         Registro, Perfil, Admin, AdminProductos, AdminUsuarios, Nosotros, NoEncontrada
```

Reutilización: `TarjetaProducto` se usa en Inicio y Catálogo; `BuscadorProductos` en Catálogo y Admin;
`BarraNavegacion` en el sitio público y en el panel admin; `CampoTexto/CampoSeleccion` en los 5 formularios.

## Patrón de diseño: Container / Presentational

- **Contenedores** (`src/pages/`): tienen el estado (`useState`), llaman a la fuente de datos y deciden qué hacer con los eventos.
- **Presentacionales** (`components/`): reciben datos y funciones por **props tipadas** y solo dibujan la interfaz.
- Los formularios guardan solo el estado de sus campos; al ser válidos entregan los datos al contenedor mediante una función (`onGuardar`, `onEnviar`, ...).
- `src/data/*DB.ts` actúa como capa de acceso a datos (módulo independiente) y es el único que toca `localStorage`.

> ⚠️ Si en clases se trabajó otro patrón (por ejemplo Custom Hooks, Context o Observer), hay que ajustarlo y actualizar esta sección.

## Rutas

| Ruta | Página |
|---|---|
| `/` | Inicio (banner + destacados) |
| `/catalogo` | Catálogo con filtros y carrito |
| `/productos/:id` | Detalle de producto (`useParams`) |
| `/novedades`, `/novedades/:id` | Novedades y detalle |
| `/nosotros`, `/contacto`, `/login`, `/registro`, `/perfil` | Páginas del sitio |
| `/admin`, `/admin/productos`, `/admin/usuarios` | Panel administrador (requiere rol Administrador) |

## Documentación

- `docs/ERS_EP2.md` – requerimientos de la solución para la EP2.
- `docs/TESTING.md` – documento de testing (configuración, casos, cobertura, pendientes).

## Trabajo con Git (completar por el equipo)

Cada integrante debe trabajar en su propia rama (`feature/...`), abrir Pull Requests y fusionar a `main`,
de modo que el historial de GitHub evidencie sus aportes individuales.
