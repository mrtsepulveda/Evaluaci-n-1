# Documento de testing – EP2

## 1. Entorno y comandos
- **Herramientas:** Vitest, React Testing Library, `@testing-library/user-event`, `@testing-library/jest-dom`, jsdom.
- **Configuración:** `vite.config.ts` (bloque `test`) y `src/test/setup.ts` (limpia el DOM y `localStorage` después de cada prueba).

| Comando | Qué hace |
|---|---|
| `npm run test:run` | Ejecuta todas las pruebas una vez. |
| `npm test` | Modo observador (re-ejecuta al guardar). |
| `npm run coverage` | Ejecuta las pruebas y genera cobertura en `coverage/` (HTML + resumen) y resultados en `reports/` (JSON + HTML). |

## 2. Casos evaluados (89 pruebas en 17 archivos)
| Archivo | Pruebas | Qué verifica |
|---|---|---|
| `utils/validaciones.test.ts` | 7 | Mensajes específicos de correo, RUN, contraseña, texto, precio e ID. |
| `data/productosDB.test.ts` | 12 | **CRUD de productos** (crear, leer, actualizar, eliminar, errores) y **filtros** (texto, categoría, ofertas, combinados, sin resultados). |
| `data/usuariosDB.test.ts` | 5 | **CRUD de usuarios** y correo duplicado. |
| `data/carrito.test.ts` | 4 | Agregar, sumar cantidad, producto sin stock, quitar y total con oferta. |
| `components/atoms/Boton.test.tsx` | 3 | Renderizado, props (variante), evento clic y botón deshabilitado. |
| `components/molecules/CampoTexto.test.tsx` | 3 | Error solo cuando corresponde, `aria-invalid`, evento de cambio. |
| `components/molecules/TarjetaProducto.test.tsx` | 5 | Props, enlace a `/productos/:id`, oferta, sin stock, evento agregar. |
| `components/molecules/BuscadorProductos.test.tsx` | 3 | Opciones de categoría y eventos de los filtros. |
| `components/organisms/GrillaProductos.test.tsx` | 2 | La lista muestra todos los elementos; mensaje cuando está vacía. |
| `components/organisms/Formulario*.test.tsx` | 14 | Formularios controlados: errores por campo solo al enviar, error específico, envío válido, dependencia región→comuna, modo edición. |
| `pages/Catalogo.test.tsx` | 6 | 85 productos, filtros por texto/categoría/ofertas, sin resultados, evento agregar. |
| `pages/AdminProductos.test.tsx` | 8 | CRUD completo en la interfaz, búsqueda, ID repetido, confirmación al eliminar. |
| `pages/AdminUsuarios.test.tsx` | 5 | CRUD completo de usuarios y búsqueda. |
| `App.test.tsx` | 12 | Rutas con parámetro, 404, navegación al detalle, rutas protegidas, login/logout, carrito y pago. |

## 3. Mocks y espías
- `vi.fn()` para comprobar que los componentes llaman a las funciones recibidas por props (`onClick`, `onAgregar`, `onGuardar`, `onEnviar`, ...) y con qué argumentos.
- `vi.spyOn(window, 'confirm')` para simular que el usuario acepta o cancela al **eliminar** o **pagar**.
- `MemoryRouter` para probar rutas sin navegador real.

## 4. Archivos incluidos y excluidos de la cobertura
- **Incluidos:** todo `src/**/*.ts(x)`.
- **Excluidos:** `src/main.tsx` (arranque), `src/test/**` (configuración), `*.test.*`, `src/types/**` (solo interfaces) y `vite-env.d.ts`.

## 5. Resultados y cobertura
> Pegar aquí la salida real después de ejecutar `npm run coverage` (tabla de cobertura y cantidad de pruebas aprobadas). El reporte HTML queda en `coverage/index.html` y `reports/html/index.html`.

| Pruebas totales | Aprobadas | Fallidas | Cobertura de líneas |
|---|---|---|---|
| _completar_ | _completar_ | _completar_ | _completar_ |

## 6. Comportamientos pendientes / límites
- No se prueba el menú hamburguesa de `BarraNavegacion` ni la adaptación visual (requiere navegador real); la responsividad se verificó manualmente.
- `ImagenProducto` (imagen de respaldo con `onError`), `Registro` y `Contacto` se prueban indirectamente; falta una prueba directa de la página de registro con usuario duplicado.
- La persistencia en `localStorage` se prueba solo para productos; sesión y carrito se verifican por su efecto en la interfaz.
- Cobertura alta no garantiza calidad: cada prueba debe tener una comprobación explícita del resultado esperado, no solo ejecutar el código.
