# ERS actualizado – Evaluación Parcial 2

Sección de requerimientos incorporados al ERS de la Evaluación 1 (Ferretería Los Maestros). Los requerimientos de la EP1 se mantienen; aquí se agregan o modifican los de la migración a React.

## 1. Restricciones tecnológicas
| ID | Requerimiento |
|---|---|
| RNF-01 | La aplicación se desarrolla con React, Vite y TypeScript. |
| RNF-02 | La interfaz es responsiva (móvil, tableta y escritorio) usando Bootstrap. |
| RNF-03 | Los componentes se organizan con Atomic Design (átomos, moléculas, organismos, plantillas y páginas). |
| RNF-04 | Se aplica el patrón Container/Presentational: las páginas gestionan estado y datos; los componentes reciben props tipadas. |
| RNF-05 | El estado se gestiona con `useState` y los formularios son controlados. |
| RNF-06 | La navegación usa React Router, incluyendo rutas con parámetro (`/productos/:id`, `/novedades/:id`). |
| RNF-07 | Las pruebas usan Vitest, React Testing Library y jsdom (mínimo 15 pruebas). |

## 2. Requerimientos funcionales
| ID | Requerimiento | Implementación |
|---|---|---|
| RF-01 | Migrar todas las páginas HTML a componentes React. | `src/pages/*` |
| RF-02 | Ver productos destacados en el inicio. | `Inicio` |
| RF-03 | Ver el catálogo completo (85 productos). | `Catalogo` |
| RF-04 | Filtrar productos por texto, categoría y ofertas. | `BuscadorProductos`, `filtrarProductos` |
| RF-05 | Ver el detalle de un producto mediante su ID en la URL. | `DetalleProducto` |
| RF-06 | Agregar/quitar productos del carrito y pagar (con confirmación). Los productos sin stock no se pueden agregar. | `PanelCarrito`, `data/carrito.ts` |
| RF-07 | Registrar usuarios con validación de RUN, correo, región/comuna y campos obligatorios. | `Registro` |
| RF-08 | Iniciar y cerrar sesión; el menú cambia según la sesión. | `Login`, `Perfil` |
| RF-09 | Enviar mensajes de contacto con validación. | `Contacto` |
| RF-10 | Ver novedades y su detalle. | `Novedades`, `NovedadDetalle` |
| RF-11 | **CRUD de productos** (crear, listar, editar, eliminar y cambiar stock) para el administrador. | `AdminProductos`, `productosDB.ts` |
| RF-12 | **CRUD de usuarios** (crear, listar, editar, eliminar) para el administrador. | `AdminUsuarios`, `usuariosDB.ts` |
| RF-13 | Solo el rol Administrador accede a `/admin/*`; los demás son redirigidos al login. | `RutaAdmin` |
| RF-14 | Mostrar página 404 en rutas inexistentes. | `NoEncontrada` |

## 3. Reglas de validación
| Campo | Regla / mensaje |
|---|---|
| Correo | Obligatorio, máx. 100, formato válido (mensajes distintos para cada caso). |
| Contraseña | Obligatoria, 4 a 10 caracteres. |
| RUN | Obligatorio, sin puntos ni guion, dígito verificador válido. |
| Nombre / apellidos / dirección / comentario | Obligatorios con largo máximo (50 / 100 / 300 / 500). |
| ID producto | 2 letras + 3 números (ej. MC999); no se puede repetir. |
| Precio | Entero mayor que 0. Precio de oferta (opcional) menor al precio normal. |

## 4. Fuente de datos simulada
Los módulos `src/data/productosDB.ts` y `src/data/usuariosDB.ts` mantienen los registros en memoria y los persisten en `localStorage`, exponiendo las funciones `crear*`, `obtener*`, `actualizar*` y `eliminar*`.
