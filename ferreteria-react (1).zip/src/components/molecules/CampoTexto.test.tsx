import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { describe, expect, it, vi } from 'vitest'
import CampoTexto from './CampoTexto'

describe('CampoTexto (molécula)', () => {
  it('muestra la etiqueta y NO muestra mensaje de error cuando no hay error', () => {
    render(<CampoTexto id="nombre" etiqueta="Nombre" valor="" onCambio={() => {}} />)
    expect(screen.getByLabelText('Nombre')).toBeInTheDocument()
    expect(screen.queryByRole('alert')).not.toBeInTheDocument()
  })

  it('muestra el mensaje de error y marca el campo como inválido', () => {
    render(<CampoTexto id="nombre" etiqueta="Nombre" valor="" onCambio={() => {}} error="El nombre es obligatorio." />)
    expect(screen.getByRole('alert')).toHaveTextContent('El nombre es obligatorio.')
    expect(screen.getByLabelText('Nombre')).toHaveAttribute('aria-invalid', 'true')
  })

  it('envía lo que escribe el usuario a través de onCambio', async () => {
    const onCambio = vi.fn()
    render(<CampoTexto id="nombre" etiqueta="Nombre" valor="" onCambio={onCambio} />)
    await userEvent.type(screen.getByLabelText('Nombre'), 'A')
    expect(onCambio).toHaveBeenCalledWith('A')
  })
})
