import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { describe, expect, it, vi } from 'vitest'
import Boton from './Boton'

describe('Boton (átomo)', () => {
  it('muestra su texto y aplica la variante de Bootstrap recibida por props', () => {
    render(<Boton variante="danger">Eliminar</Boton>)
    const boton = screen.getByRole('button', { name: 'Eliminar' })
    expect(boton).toBeInTheDocument()
    expect(boton).toHaveClass('btn', 'btn-danger')
  })

  it('llama a onClick una vez al hacer clic', async () => {
    const onClick = vi.fn()
    render(<Boton onClick={onClick}>Guardar</Boton>)
    await userEvent.click(screen.getByRole('button', { name: 'Guardar' }))
    expect(onClick).toHaveBeenCalledTimes(1)
  })

  it('no llama a onClick si está deshabilitado', async () => {
    const onClick = vi.fn()
    render(
      <Boton onClick={onClick} disabled>
        Guardar
      </Boton>,
    )
    await userEvent.click(screen.getByRole('button', { name: 'Guardar' }))
    expect(onClick).not.toHaveBeenCalled()
  })
})
