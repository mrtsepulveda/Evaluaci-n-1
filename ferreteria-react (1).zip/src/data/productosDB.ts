// Fuente de datos simulada de productos.
// Funciona como una "base de datos" en memoria con persistencia en localStorage
// e implementa el CRUD completo: crear, leer, actualizar y eliminar.
import type { FiltrosProducto, Producto } from '../types'
import { guardarAlmacenado, leerAlmacenado } from './almacenamiento'
import { productosIniciales } from './productosIniciales'

export const CLAVE_PRODUCTOS = 'catalogoFerreteria'

let productos: Producto[] = cargarInicial()

function cargarInicial(): Producto[] {
  const guardados = leerAlmacenado<Producto[]>(CLAVE_PRODUCTOS)
  return guardados ?? productosIniciales.map((p) => ({ ...p }))
}

function persistir(): void {
  guardarAlmacenado(CLAVE_PRODUCTOS, productos)
}

// ---------- READ ----------
export function obtenerProductos(): Producto[] {
  return productos.map((p) => ({ ...p }))
}

export function obtenerProductoPorId(id: string): Producto | undefined {
  const encontrado = productos.find((p) => p.id === id)
  return encontrado ? { ...encontrado } : undefined
}

export function obtenerCategorias(): string[] {
  return [...new Set(productos.map((p) => p.categoria))].sort()
}

// Filtros de búsqueda: texto (en nombre, id o descripción), categoría y ofertas.
export function filtrarProductos(lista: Producto[], filtros: FiltrosProducto): Producto[] {
  const texto = filtros.texto.trim().toLowerCase()
  return lista.filter((p) => {
    const coincideTexto =
      texto === '' ||
      p.nombre.toLowerCase().includes(texto) ||
      p.id.toLowerCase().includes(texto) ||
      p.descripcion.toLowerCase().includes(texto)
    const coincideCategoria = filtros.categoria === '' || p.categoria === filtros.categoria
    const coincideOferta = !filtros.soloOfertas || p.enOferta === true
    return coincideTexto && coincideCategoria && coincideOferta
  })
}

// ---------- CREATE ----------
export function crearProducto(nuevo: Producto): Producto {
  if (productos.some((p) => p.id === nuevo.id)) {
    throw new Error(`Ya existe un producto con el ID ${nuevo.id}`)
  }
  productos = [...productos, { ...nuevo }]
  persistir()
  return { ...nuevo }
}

// ---------- UPDATE ----------
export function actualizarProducto(id: string, cambios: Partial<Producto>): Producto {
  const indice = productos.findIndex((p) => p.id === id)
  if (indice === -1) {
    throw new Error(`No existe un producto con el ID ${id}`)
  }
  const actualizado: Producto = { ...productos[indice], ...cambios, id }
  productos = productos.map((p, i) => (i === indice ? actualizado : p))
  persistir()
  return { ...actualizado }
}

// ---------- DELETE ----------
export function eliminarProducto(id: string): boolean {
  const existe = productos.some((p) => p.id === id)
  if (!existe) return false
  productos = productos.filter((p) => p.id !== id)
  persistir()
  return true
}

// Vuelve a los datos iniciales (útil para pruebas).
export function reiniciarProductos(): void {
  productos = productosIniciales.map((p) => ({ ...p }))
  persistir()
}
