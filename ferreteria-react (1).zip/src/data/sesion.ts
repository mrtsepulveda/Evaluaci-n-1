// Manejo de la sesión simulada (se guarda en localStorage).
import type { Sesion } from '../types'
import { borrarAlmacenado, guardarAlmacenado, leerAlmacenado } from './almacenamiento'
import { obtenerUsuarioPorCorreo } from './usuariosDB'

export const CLAVE_SESION = 'sesionFerreteria'

export function leerSesion(): Sesion | null {
  return leerAlmacenado<Sesion>(CLAVE_SESION)
}

// Si el correo está registrado usa su rol; si no, es administrador solo si contiene "admin" (igual que la evaluación 1).
export function crearSesion(correo: string): Sesion {
  const usuario = obtenerUsuarioPorCorreo(correo)
  const rol = usuario ? usuario.rol : correo.toLowerCase().includes('admin') ? 'Administrador' : 'Cliente'
  const sesion: Sesion = { correo, rol }
  guardarAlmacenado(CLAVE_SESION, sesion)
  return sesion
}

export function cerrarSesionGuardada(): void {
  borrarAlmacenado(CLAVE_SESION)
}
